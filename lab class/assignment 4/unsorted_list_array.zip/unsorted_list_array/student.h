#ifndef STUDENT_H_INCLUDED
#define STUDENT_H_INCLUDED
#include<bits/stdc++.h>
using namespace std;
//template <class ST>
class Student{

private:
    int id;
    string name;
    float cgpa;
public:
    Student();
    Student(int, string, float);
    void setId(int);
    void setName(string);
    void setCgpa(float);
    int getId();
    string getName();
    float getCgpa();
    void Print();
};

#endif // STUDENT_H_INCLUDED
